# Provider and Operations Notes

## Current provider information

The repository `providers.json` contains provider presets for multiple work providers, including instruction providers and engineer-report providers. It stores `work_provider` as a manual-input config, with other fields controlled through mapping methods such as `single_label`, `two_labels`, `fixed_position`, `fixed_position_label`, `single_label_offset` and presence-check-style fields. fileciteturn20file0 fileciteturn21file0

`Mapped Principals.xlsx` and the Job Sheet backups should be used to validate provider/work-provider codes and operational rules. The Job Sheet Principal data includes columns such as solicitor/work provider, EVA code, Box code, inbox, solicitor instructions, whether to drag into EVA, sent-mino, image location, image-based/address decision and sending-report rules.

## Current spreadsheet signals

The conditional formatting backup includes rules for:

- 4-week-old dates;
- 3-week-old dates;
- current/past due dates;
- repeated registrations with spaces ignored. fileciteturn0file3

These are not mapper features, but they are useful automation/dashboard requirements.

## Communication requirements

The tone profile describes CE communications as professional, neutral, courteous, assured, technically grounded and concise. This is relevant to future copy-only chaser drafts and report-delivery templates, not to base extraction. fileciteturn0file12
