# Phase 2: Automation Enhancement Plan

## Position in roadmap

This phase starts only after the mapper rebuild has a stable core, field model, provider rules, review status and export profiles. Automation feeds work into the mapper; it does not replace mapper review.

## Goal

Reduce manual intake, file storage and work tracking while retaining human control over extracted data and external communication.

## Automation components

### 1. Intake adapter

Options:

- Microsoft Graph mailbox polling/change notifications;
- watched folder for manual bridge;
- manual import queue.

The initial automation plan proposes Microsoft Graph for inbox monitoring and attachment parsing. That remains sensible, but it should consume the mapper through an `IntakeAdapter`, not be coded into the desktop app. fileciteturn0file0

### 2. Work-item queue

Create one work item per case/intake.

Recommended statuses:

- received;
- awaiting_related_files;
- files_stored;
- extraction_started;
- extracted;
- validation_failed;
- needs_review;
- reviewed;
- ready_for_eva;
- failed_retryable;
- failed_terminal;
- archived.

These statuses mirror the broader target operating model and make failures visible before EVA submission.

### 3. File correlation

Automation must handle:

- instruction attached to email;
- images attached to same email;
- images sent separately;
- multiple attachments;
- duplicate emails;
- duplicate attachments by checksum;
- image-only documents;
- engineer reports linked to instructions.

### 4. Storage adapter

Box or local archive later stores:

- original email copy;
- instruction document;
- engineer report document;
- images;
- exported JSON;
- review/audit metadata.

Source files must be immutable once archived.

### 5. Review dashboard

The dashboard should show:

- cases awaiting images;
- cases missing required fields;
- cases with duplicate VRM/reference;
- cases ready for review;
- cases approved for EVA;
- failed/retryable cases.

The current job sheet’s conditional-formatting rules show operational signals that should survive in dashboard form: aged dates, due/current dates and repeated registrations. fileciteturn0file3

### 6. Missing-information tasking

Use the Principals/Garages/job-sheet data as migration input for image-location and contact rules. The current job sheet has provider-specific rules such as image locations, whether to use image-based assessment or address, and report-sending rules. This should become data/configuration, not spreadsheet/VBA logic.

### 7. Copy-only chaser drafts

Use the CE tone profile for draft messages: professional, calm, concise, technically authoritative, no sales tone, no emotional language. fileciteturn0file12

Drafts should be copy-only or approval-required at first. CollisionAutomation’s product scope also treats external sending/submission as non-goals in early phases. fileciteturn34file0

## Exclusions

Phase 2 still excludes:

- EVA API submission;
- unattended external communication;
- final engineering reports;
- valuation or liability conclusions;
- auto-approval without performance evidence.

## Architecture

```text
Outlook / watched folder
  -> IntakeAdapter
  -> WorkItemStore
  -> StorageAdapter
  -> MapperCore.extract_and_map()
  -> ReviewQueue
  -> ExportProfile / later EVAQueue
```

The base mapper core should expose pure functions/services for extraction and mapping so the automation worker can call them without a UI.

## Phase 2 deliverables

1. Work-item database.
2. Intake connector in sandbox mode.
3. Attachment download and checksum logic.
4. File archive/storage adapter.
5. Review dashboard/control table.
6. Missing-information task module.
7. Copy-only chaser draft module.
8. Audit log and retry/quarantine rules.
9. Shadow-mode comparison report.

## Phase 2 exit criteria

- Incoming candidate emails become work items.
- Source files are captured and archived without loss.
- Mapper core processes archived files consistently with manual import.
- Human reviewers can correct/approve results.
- Dashboard replaces or shadows the spreadsheet’s key operational signals.
- No external message is sent and no EVA record is created without explicit approval.
