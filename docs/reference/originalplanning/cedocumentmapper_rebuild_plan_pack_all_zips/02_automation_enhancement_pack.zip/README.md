# Automation Enhancement Pack

This zip contains the separate automation plan. It assumes the base mapper has already been rebuilt and can produce reviewed canonical case data.

Read in order:

1. `08_PHASE_2_AUTOMATION_ENHANCEMENT_PLAN.md`
2. `10_DELIVERY_ROADMAP_AND_BACKLOG.md`
3. `11_RISKS_DECISIONS_OPEN_QUESTIONS.md`
4. `02_SOURCE_REGISTER.md`
