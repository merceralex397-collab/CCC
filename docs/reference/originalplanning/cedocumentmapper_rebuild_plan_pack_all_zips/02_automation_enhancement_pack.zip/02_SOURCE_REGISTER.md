# Source Register

Date prepared: 2026-05-22

This register records the project files, repository files, and connected-source materials used to produce the rebuild plan. The plan treats the current repository as a proven prototype, not as the architecture to keep.

## Primary repository reviewed: `collisionengineers/cedocumentmapper`

| Source | Evidence used | Planning implication |
|---|---|---|
| `README.md` | Current version history from early v16 changes through importer, mileage, engineer report, export, MSG, address, and image-export revisions. fileciteturn8file0 fileciteturn9file0 | The existing tool is operationally useful but has accumulated many version-specific behaviours that need to become explicit, tested product requirements. |
| `app.py` — constants and schema | Field order, mapping-method list, presence-check fields, OCR limit, current dependencies and file imports. fileciteturn10file0 | The rebuild must preserve the canonical field order and mapping behaviours while moving them into stable schema/config modules. |
| `app.py` — settings and provider store | OneDrive-safe Desktop/Documents resolution, migration of old app data, user `providers.json` seeding, provider normalisation. fileciteturn11file0 | Settings/presets need formal versioning and migration, not ad hoc in-line logic. |
| `app.py` — extraction engine | DOCX headers/footers/text boxes, DOC via Word/LibreOffice/antiword, EML/MSG extraction, PDF block extraction, OCR fallback. fileciteturn12file0 fileciteturn13file0 | Extractors should become independent services/modules with fixture tests and per-extractor evidence. |
| `app.py` — mapping and normalisation | Single Label, Two Labels, Fixed Position, Fixed Position + Label, Single Label +/-, Email Date, presence checks, field extraction, image extraction. fileciteturn14file0 | Mapping rules should become a typed rule engine with previewable matches and provider-rule tests. |
| `app.py` — normalisers/export helpers/UI state | Address, date, VRM, mileage normalisation; RJS DOC builder; `App` state and UI variables. fileciteturn15file0 | Normalisation and export profiles should be isolated from the UI and from parser code. |
| `app.py` — UI | Minimal/expanded view, detected fields, provider setup, method dropdowns, hidden method behaviour for VAT/Mileage Unit. fileciteturn16file0 | The rebuilt UI should preserve the simple workflow but separate UI state from domain logic. |
| `app.py` — batch, engineer report, export | Engineer report rules, batch-mode restrictions, current export gating, preparation of JSON and image outputs. fileciteturn17file0 | Batch and engineer-report overlay should become explicit workflows with audit records and tests. |
| `app.py` — highlights and main entrypoint | Engineer-report red-border highlight; preview highlighting and search; Tkinter entrypoint. fileciteturn18file0 | Visual evidence and replacement/touch status should be retained but backed by field-level provenance. |
| `requirements.txt` | PyMuPDF, pypdf, Pillow, python-docx, tkinterdnd2, extract-msg, pytesseract, pywin32. fileciteturn19file0 | Dependency set is workable but should be pinned/validated through CI and packaging tests. |
| `providers.json` | Many real-world provider presets with work-provider output codes, detect phrases, mapping rules, current-date flags, force-postcode flags, and engineer-report presets. fileciteturn20file0 fileciteturn21file0 | Provider data must be migrated, testable, versioned, and separated from bundled defaults/user overrides. |
| `.gitignore` | Excludes build/dist, Tesseract binary, bytecode, local Claude settings. fileciteturn22file0 | Packaging artifacts and bundled OCR binaries should stay out of source, with separate build instructions. |

## Connected test/base-concept repositories

| Repository/source | Evidence used | Planning implication |
|---|---|---|
| `merceralex397-collab/collisionpdf` — confidence scoring | Operator-facing labels: Strong, Check, Blocked, Missing; deterministic machine scores; export guard not relying on confidence alone. fileciteturn29file0 | Adopt labelled confidence/evidence in the rebuilt mapper, but keep human approval as the final control. |
| `merceralex397-collab/collisionpdf` — architecture | Proposed shape: native app shell, local parser API, worker service, database, immutable archive, schemas; worker handles Graph/watched-folder intake. fileciteturn30file0 | Useful as a future full automation architecture, but the mapper rebuild should start with a local, automation-ready core. |
| `merceralex397-collab/collisionpdf` — schema | `collision_case_intake.v1` includes case, documents, fields, quality, review, export, integrations, and audit sections. fileciteturn31file0 | Use a canonical internal model richer than the current flat JSON; expose the current flat JSON as a compatibility export profile. |
| `merceralex397-collab/collisionautomation` — README | Demo scope: case queue, missing-information view, engineer-pack generator, deterministic suggestions, human approval, no final expert decisions. fileciteturn33file0 | Strong guide for later automation UI/operating model, but too broad for the first mapper rebuild. |
| `merceralex397-collab/collisionautomation` — product scope | Phase-one demo: deterministic classification/extraction, evidence matching, missing-info tasking, copy-only chaser drafts; external sending/system submission as non-goals. fileciteturn34file0 | Supports keeping automation and external integrations as separate phases behind approval gates. |

## Uploaded project documentation and files

| File | Evidence used | Planning implication |
|---|---|---|
| `phase_initial_automation.md` | Existing automation-first plan covering mapper upgrades, Outlook intake, EVA integration, Box storage, spreadsheet replacement. fileciteturn0file0 | Good component list, but the sequence should be revised: rebuild the base mapper first, then layer automation and EVA separately. |
| `Final Format Example 02.json` | Current flat JSON contract and field order, including Work Provider, VRM, Vehicle Model, dates, address, VAT Status, Mileage, Mileage Unit. fileciteturn0file1 | Preserve as `legacy_flat_v1` export profile and regression fixture. |
| `claudechat.md` | Prior development transcript: UX constraints, provider presets, mapping methods, batch mode, engineer report logic, importer requirements. fileciteturn0file2 | Treat as the informal requirements archive; convert into formal requirements and tests. |
| `Backup of Conditional Formatting 260202.txt` | Age, due-date and duplicate-registration rules for current job-sheet monitoring. fileciteturn0file3 | Later dashboard/control-table workflows should preserve these operational signals. |
| `EVA User Guide.pdf` | Manual EVA setup needs offline email, instruction, images; EVA pages require Reg No, Principal, Inspection Type, Case ID/PO, Insured, Claim No, Incident Date, inspection address/date, Speedo, valuation, and photo ordering. fileciteturn0file4 | EVA integration should not be attempted until the base data model can represent these fields and evidence. |
| `Sentry_API_Complete_Guide.md` | API auth, token refresh, Instruct Claim, Claim Location Update, Authority Status, Submit Note, Claim Update, Submit Report, retrieval. fileciteturn0file5 | Define an EVA adapter later; do not bake Sentry fields into the mapper core. |
| `evaapidocs.pdf` | Sentry API v1.2 details: auth, request models, accepted values, response models, identifier combinations. fileciteturn0file6 | Use for phase-three endpoint mapping and validation rules. |
| `Standard Audatex Invoice.docx`, `Website Invoice Template.docx` | Audatex invoice layouts and current website invoice fields. fileciteturn0file7 fileciteturn0file8 | Related financial templates are adjacent assets, not part of the first mapper MVP unless invoicing is intentionally added. |
| `handover.docx` | Operational handover for job sheet, Z drive, CE Document Mapper behaviour, provider settings, batch processing, engineer reports, OCR, mapping methods. fileciteturn0file9 | High-value requirements source; confirms current tool assumptions and spreadsheet fragility. |
| `CE Communication Style & Tone Profile.docx` | Communication tone: professional, calm, technical, concise, no sales tone or emotional language. fileciteturn0file12 | Use later for chaser drafts and review communications; not part of base extraction. |
| `Mapped Principals.xlsx` | Principal/work-provider code list, including CNX/EVA engineer providers and many live provider codes. | Use for provider/preset crosswalk and work-provider code validation. |
| `Backup of CE Job Sheet 260429.xlsm` and `Backup of CE Job Sheet 260309.xlsm` | Jobs, Principals and Garages sheets; current operational columns, image-location rules, folder references, contact data. | Later automation should treat this as migration input and should not depend on brittle Excel/VBA structure. |
| `collision-engineers-context-pack.zip` | Project brief, business context, workflow, target workflow, architecture, data model, prompts, compliance, roadmap, test plan. | Useful strategic context; its automation centre plan should be recast around mapper-first delivery. |
| `collision_project_context_pack.zip` | Index, current process, target model, Outlook/Box/EVA context, data model, workflow states, review, QA, roadmap, runbooks. | Strong future automation source; do not front-load it before base mapper reliability is proven. |
| `Collision Engineers Whiteboard.jam` | Whiteboard file present; not decomposed into text in this pack. | Record as a source asset for later visual workflow review. |
