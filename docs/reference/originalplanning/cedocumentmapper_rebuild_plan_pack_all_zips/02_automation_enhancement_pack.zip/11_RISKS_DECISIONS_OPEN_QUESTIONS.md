# Risks, Decisions and Open Questions

## Key risks

### 1. Over-automation before extraction reliability

Risk: attaching Outlook, Box and EVA to an unstable mapper creates hidden failure modes.

Control: rebuild mapper first, then run automation in shadow/supervised mode.

### 2. Provider-rule drift

Risk: provider presets are edited ad hoc and break silently.

Control: schema validation, provider fixtures, migration backups and rule-test UI.

### 3. Flat JSON becomes too limiting

Risk: current flat JSON does not carry evidence, review state, documents, images or audit.

Control: keep flat export as compatibility profile but use canonical internal model.

### 4. OCR false confidence

Risk: OCR values look valid but are wrong.

Control: label OCR-derived values as Check unless manually confirmed; keep evidence visible.

### 5. EVA field mismatch

Risk: current mapper fields do not cover all manual EVA setup requirements.

Control: add EVA-specific fields to canonical model before API work; do not distort base mapper fields.

### 6. Real client data in fixtures

Risk: regression tests accidentally store personal/client data.

Control: anonymised/private fixture policy.

### 7. Spreadsheet dependency

Risk: current Excel/VBA job sheet remains a hidden system of record and breaks through formatting/column changes.

Control: use spreadsheet/job-sheet only as migration input; move toward explicit work-item store and dashboard.

## Decisions recommended now

| Decision | Recommendation |
|---|---|
| Rebuild or continue patching? | Rebuild from scratch, preserving behaviours as requirements. |
| Automation in first release? | No. Keep Phase 1 local/manual. |
| EVA API in first release? | No. Design adapter boundary only. |
| Preserve current flat JSON? | Yes, as `legacy_flat_v1`. |
| Keep provider presets? | Yes, through tested migration. |
| Add field confidence? | Yes, as operator labels plus evidence, not as unsupported probabilities. |
| Human review required? | Yes by default. |
| Use connected test projects? | Yes as design references, not as direct implementation to copy wholesale. |

## Open questions

1. Which UI technology should be used for the rebuild: Tkinter refactor, PySide6/PyQt, or local service + separate UI shell?
2. Which current exports are truly required besides JSON and images?
3. Which providers should be in the first fixture suite?
4. Which sample documents can be anonymised and stored for tests?
5. Should local case history be stored in SQLite, JSONL or not at all in Phase 1?
6. Is the current six-line inspection address export still mandatory for all consumers?
7. Does Work Provider always equal a short code, and should it be validated against Mapped Principals/job-sheet data?
8. Which EVA integration route is actually available: JSON import, Sentry API, or both?
9. Is there an EVA sandbox/test credential path?
10. Which mailbox/folder should automation pilot against after base rebuild?
11. Is Box the confirmed archive system, and what metadata fields are mandatory?
12. What is the minimum acceptable review trail for audit/compliance?

## Watch item

The README is valuable but appears to trail some code behaviours. For example, `app.py` contains OneDrive path migration comments referring to V62, while the fetched README history ends at V50. This should be resolved by making release notes and requirements part of each build gate. fileciteturn9file0 fileciteturn11file0
