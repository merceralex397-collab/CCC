# Delivery Roadmap and Backlog

## Roadmap overview

### Stream 1 — Base mapper rebuild

| Phase | Outcome | Notes |
|---|---|---|
| 1.0 Discovery and fixture capture | Formal requirements, anonymised fixtures, provider inventory | Convert `claudechat.md`, handover and README history into testable requirements. |
| 1.1 Core schema and export contract | Field schema, `legacy_flat_v1`, canonical draft model | Preserve current flat JSON exactly. |
| 1.2 Extractor modules | PDF/DOCX/DOC/EML/MSG/image extractors | Use current behaviours as regression targets. |
| 1.3 Rule engine | Typed mapping rules and provider detection | UI-independent execution. |
| 1.4 Provider migration | Old `providers.json` to new schema | Backup, validate, report changes. |
| 1.5 Review UI | Evidence/status per field, provider editor, batch/engineer workflows | Preserve simple day-to-day UX. |
| 1.6 Exports | JSON and image export; optional RJS/Audatex exports | Export profiles, not one-off UI handlers. |
| 1.7 Packaging and pilot | Windows portable build and test harness | Shadow against current process. |

### Stream 2 — Automation enhancement

| Phase | Outcome |
|---|---|
| 2.1 Work-item store | Stable internal IDs, statuses, audit events. |
| 2.2 Intake spike | Graph/watched-folder intake in sandbox. |
| 2.3 Storage spike | Box/local archive with immutable source files. |
| 2.4 Review queue | Dashboard/control table replacing spreadsheet signals. |
| 2.5 Missing-info workflow | Tasks and copy-only chaser drafts. |
| 2.6 Pilot | Shadow mode, compare against manual workflow. |

### Stream 3 — EVA API enhancement

| Phase | Outcome |
|---|---|
| 3.1 EVA payload preview | Map approved canonical cases to Sentry payload previews. |
| 3.2 Sandbox submit | Token client and supervised sandbox/test submission. |
| 3.3 Production supervised submit | Human-approved submission with audit and duplicate controls. |
| 3.4 Endpoint expansion | Location, note, authority, claim update, report endpoints as needed. |
| 3.5 Limited auto-submit | Only after measured low-risk success. |

## High-priority backlog

### Base rebuild backlog

- Define `FieldKey` enum and field metadata.
- Implement `legacy_flat_v1` exporter with exact labels/order.
- Implement `CaseDraft` canonical model.
- Port current extractors into modules.
- Add PDF block extraction fixture.
- Add MSG HTML body fixture.
- Add legacy DOC header/footer fixture.
- Add OCR one-image-per-page fixture.
- Implement rule engine with typed configs.
- Implement rule tester UI.
- Implement provider schema migration.
- Add provider-rule fixture suite.
- Add engineer-report overlay service.
- Add field evidence sidebar/popover.
- Add release build script.
- Add regression test runner.

### Automation backlog

- Define work item schema.
- Define status state machine.
- Implement watched-folder adapter first.
- Implement Graph adapter second.
- Implement attachment checksum/dedupe.
- Implement source archive adapter.
- Implement missing-image detection.
- Implement dashboard/control table.
- Implement copy-only chaser drafts using CE tone rules.
- Implement operational audit exports.

### EVA backlog

- Define EVA payload DTOs.
- Map mapper fields to `Instruction/Inspection` payload.
- Map inspection location fields to `Claim/LocationUpdate` payload.
- Implement token client with 30-second refresh buffer.
- Implement validation-only payload preview.
- Implement sandbox submit.
- Implement duplicate guard.
- Implement response/error store.
- Implement manual approval gate.

## Suggested first sprint

1. Confirm build language/UI choice.
2. Freeze field contract and export profile.
3. Create fixture corpus plan and anonymisation process.
4. Create new repo/package skeleton.
5. Implement field model, normalisers and flat JSON export.
6. Port PDF extractor and test it against the known table layout issue.
7. Port provider detection and Single Label/Two Labels rules.

## Suggested second sprint

1. Port DOCX/DOC/EML/MSG extractors.
2. Port remaining mapping methods.
3. Build provider-rule migration.
4. Build basic detected-fields UI.
5. Add rule tester.
6. Add provider fixture tests.

## Suggested third sprint

1. Implement batch mode.
2. Implement engineer-report overlay and touched-field evidence.
3. Implement image export.
4. Implement packaging smoke test.
5. Run shadow pilot with representative documents.
