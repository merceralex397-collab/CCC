# Phase 1: Ground-Up Rebuild of Base Functionality

## Goal

Build a new `cedocumentmapper` from scratch as a local, human-reviewed document mapping tool. It should not ingest Outlook mail, upload to Box, communicate with EVA, or call the EVA API in this phase. It must, however, be architected so later automation and EVA adapters can use the same core.

## Product boundary

### Included

- Manual file import via drag/drop and file picker.
- PDF, DOC, DOCX, EML, MSG ingestion.
- OCR fallback for specific scanned-document cases.
- Provider detection and provider rule editor.
- Deterministic field extraction and normalisation.
- Field-level evidence and confidence labels.
- Human review/correction.
- Batch processing.
- Engineer-report overlay.
- JSON export using the existing flat field order.
- Image export.
- Optional RJS/Audatex document exports only if explicitly retained as compatibility outputs.
- Settings and provider migration from current `providers.json`.

### Excluded

- Outlook/Graph mailbox polling.
- Box file/folder creation.
- Spreadsheet automation.
- EVA/Sentry API calls.
- WhatsApp/email sending.
- Auto-approval of cases.
- Engineer judgement or final report generation.

## Base phase deliverables

### 1. Field and export contract

Create a formal field schema preserving the current order:

1. Work Provider
2. VRM
3. Vehicle Model
4. Claimant Name
5. Reference
6. Incident Date
7. Instruction Date
8. Inspection Date
9. Inspection Address
10. Accident Circumstances
11. VAT Status
12. Mileage
13. Mileage Unit

The current `DEFAULT_FIELDS` in `app.py` and `Final Format Example 02.json` are the source of truth for this compatibility contract. fileciteturn10file0 fileciteturn0file1

### 2. Extraction engine

Implement extraction modules:

- `PdfExtractor`: PyMuPDF block text, page/image metadata, pypdf fallback, OCR fallback policy.
- `DocxExtractor`: body paragraphs, tables, headers, footers, textboxes, embedded media.
- `DocExtractor`: Word automation where available, LibreOffice conversion fallback, antiword only as last-resort text.
- `EmailExtractor`: EML and MSG headers/body/attachments with HTML cleanup.
- `ImageExtractor`: embedded image extraction and direct image metadata.

Each extractor returns:

- raw text;
- normalised text blocks;
- source evidence locations;
- notes/warnings;
- extracted images/media references.

### 3. Mapping/rule engine

Implement typed mapping rules:

- Single Label;
- Two Labels;
- Fixed Position;
- Fixed Position + Label;
- Single Label +/-;
- Email Date;
- Manual Input;
- Presence Check, used for VAT Status and Mileage Unit.

The rule engine must be independent of the UI. A provider rule can be executed in tests without opening the application.

### 4. Provider library

Provider presets should be stored as versioned JSON:

```json
{
  "schema_version": "provider_rules.v1",
  "providers": [
    {
      "provider_id": "rjs_default",
      "display_name": "RJS",
      "work_provider_code": "RJS",
      "detect_phrases": [],
      "rules": {},
      "flags": {
        "engineer_report": false,
        "use_current_date_for_inspection_date": false,
        "force_postcode_for_inspection_address": false
      }
    }
  ]
}
```

Migration must read the current `providers.json`, preserve work-provider codes, detect phrases, flags and field rules, and write the new schema only after validation. Current provider presets include both ordinary instructions and engineer-report providers such as CNX/EVA-style mappings. fileciteturn20file0 fileciteturn21file0

### 5. Review UI

The UI should stay simple:

- left: detected/reviewed fields;
- middle: source preview/evidence;
- right: provider setup;
- minimal view for daily use;
- expanded view for setup.

Improvements:

- field value includes status: Missing, Check, Strong, Blocked;
- each field can show evidence snippet and method;
- engineer report touched fields remain visibly marked;
- rule tester previews matches while editing provider rules;
- batch navigation shows per-document provider/status.

CollisionPDF’s confidence label model is a good starting point because it uses operator-friendly labels rather than pretending deterministic scores are probabilities. fileciteturn29file0

### 6. Export profiles

Create explicit export profiles:

- `legacy_flat_v1`: exactly current JSON labels and order.
- `canonical_case_v1`: internal richer model with documents, evidence, quality, review and audit.
- optional `image_export_v1`: embedded image export.
- optional `rjs_doc_v1`: if RJS DOC export remains needed.

The flat JSON should stay available even if the internal model becomes richer.

### 7. QA harness

Minimum test areas:

- current JSON contract;
- each mapping method;
- provider migration;
- each file type extractor;
- OCR policy;
- field normalisers;
- batch mode;
- engineer report overlay;
- export gates and filename rules;
- provider fixture coverage.

## Base phase exit criteria

The base rebuild is ready for pilot only when:

1. It imports the same file types as the current tool.
2. It exports the same flat JSON for fixture cases.
3. It preserves current provider presets through migration.
4. It passes fixture tests for each known provider class.
5. It visibly shows evidence/status for every mapped field.
6. It supports batch and engineer-report overlay with tests.
7. It packages as a Windows desktop app without external automation dependencies.
8. It has a stable canonical case model that later automation/EVA adapters can consume.
