# Base Rebuild Pack

This zip contains the mapper-first rebuild plan. It deliberately excludes Outlook/Box automation and EVA API integration except for adapter boundaries.

Read in order:

1. `01_PLAN_REVIEW.md`
2. `03_CURRENT_TOOL_AUDIT.md`
3. `04_GROUND_UP_REBUILD_BASE_FUNCTIONALITY.md`
4. `05_BASE_ARCHITECTURE_SPEC.md`
5. `06_DATA_MODEL_PROVIDER_RULES_AND_JSON.md`
6. `07_TESTING_QA_AND_MIGRATION.md`
7. `10_DELIVERY_ROADMAP_AND_BACKLOG.md`
8. `11_RISKS_DECISIONS_OPEN_QUESTIONS.md`
9. `02_SOURCE_REGISTER.md`
