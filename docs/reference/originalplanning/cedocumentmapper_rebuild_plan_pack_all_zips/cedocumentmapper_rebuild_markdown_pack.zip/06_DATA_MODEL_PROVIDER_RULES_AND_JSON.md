# Data Model, Provider Rules and JSON Contracts

## Two-layer model

Use two data contracts:

1. **Compatibility export** — the current flat JSON used by the existing workflow.
2. **Canonical case model** — richer internal data with field evidence, documents, images, validation, review and audit.

This mirrors the principle in the broader project context: source documents should become canonical JSON before validation/review and any EVA-specific payload. The context pack states the boundary as `PDF/email/images -> extraction -> canonical JSON -> validation/review -> EVA-specific JSON`.

## Compatibility export: `legacy_flat_v1`

The exact output labels and order should remain:

```json
{
  "Work Provider": "SBL",
  "VRM": "RJ62RTU",
  "Vehicle Model": "Skoda Superb",
  "Claimant Name": "Mr Piotr Robaczkiewicz",
  "Reference": "SBL-B0492438",
  "Incident Date": "14/04/2026",
  "Instruction Date": "15/04/2026",
  "Inspection Date": "15/04/2026",
  "Inspection Address": "...",
  "Accident Circumstances": "...",
  "VAT Status": "No",
  "Mileage": "53600",
  "Mileage Unit": "Km"
}
```

This is based on `Final Format Example 02.json` and the current `DEFAULT_FIELDS`. fileciteturn0file1 fileciteturn10file0

## Canonical internal model: `case_draft_v1`

The internal model should look more like this:

```json
{
  "schema_version": "case_draft_v1",
  "case_id": "LOCAL-2026-000001",
  "source": {
    "origin": "manual_import",
    "received_at": null,
    "operator": null
  },
  "documents": [
    {
      "document_id": "DOC-001",
      "role": "instruction",
      "filename": "instruction.pdf",
      "content_type": "application/pdf",
      "sha256": "...",
      "extractor": "pdf_pymupdf_blocks"
    }
  ],
  "provider": {
    "provider_id": "sbl_default",
    "display_name": "SBL",
    "work_provider_code": "SBL",
    "detected": true
  },
  "fields": {
    "vrm": {
      "label": "VRM",
      "value": "RJ62RTU",
      "normalized_value": "RJ62RTU",
      "status": "Strong",
      "method": "single_label",
      "evidence": [
        {
          "document_id": "DOC-001",
          "page": 1,
          "text": "Vehicle Reg: RJ62 RTU",
          "start": null,
          "end": null
        }
      ],
      "warnings": [],
      "review": {
        "state": "not_reviewed",
        "manually_edited": false
      }
    }
  },
  "review": {
    "required": true,
    "status": "not_started",
    "approved_for_export": false
  },
  "audit": []
}
```

CollisionPDF’s schema is a useful reference because it makes case, documents, fields, quality, review, export, integrations and audit explicit. fileciteturn31file0

## Field statuses

Adopt operator-facing labels:

- `Strong`: clear source evidence or manual confirmation exists.
- `Check`: value found but should be reviewed.
- `Blocked`: conflict or critical warning prevents approval/export.
- `Missing`: no usable value found.

This is directly aligned with the connected `collisionpdf` confidence-scoring work. fileciteturn29file0

## Provider-rule schema

Use one provider schema for all mappings:

```json
{
  "schema_version": "provider_rules.v1",
  "providers": [
    {
      "provider_id": "cnx_engineers",
      "display_name": "CNX (Engineers)",
      "work_provider_code": "",
      "detect_phrases": ["Connexus Vehicle Assessors"],
      "flags": {
        "engineer_report": true,
        "use_current_date_for_inspection_date": false,
        "force_postcode_for_inspection_address": false
      },
      "rules": {
        "mileage": {
          "method": "single_label",
          "config": "Speedo:"
        },
        "mileage_unit": {
          "method": "presence_check",
          "tokens": ["Miles"],
          "positive": "Miles",
          "negative": "Km"
        }
      }
    }
  ]
}
```

## Provider migration

Migration must handle:

- old method names via `LEGACY_METHOD_TO_DISPLAY_CODE`;
- old `field_labels` blocks;
- work-provider manual-input values;
- current-date inspection date;
- force-postcode flag;
- engineer-report flag;
- VAT/Mileage Unit presence-check semantics;
- provider naming vs Work Provider output code.

The current code already normalises several legacy cases, but the rebuild should make migration a tested command with backup/rollback. fileciteturn11file0

## Rule testing

Each provider should have fixture files and expected field outputs. Minimum provider test record:

```json
{
  "provider_id": "sbl_default",
  "fixture": "fixtures/sbl/instruction_001.pdf",
  "expected_legacy_flat_v1": {
    "Work Provider": "SBL",
    "VRM": "RJ62RTU"
  },
  "expected_warnings": [],
  "expected_status": {
    "vrm": "Strong",
    "inspection_address": "Check"
  }
}
```

## JSON export rules

- `legacy_flat_v1` should export only reviewed/current field values.
- Dates should be normalised to `DD/MM/YYYY` at export time.
- VRM should be normalised by removing whitespace and uppercasing.
- Inspection Address should retain the current six-line output shape unless the business formally changes it.
- Mileage should be digits only.
- Mileage Unit should be only `Miles`, `Km`, or blank.
- VAT Status should be only `Yes`, `No`, or blank.
- JSON export should remain gated by Work Provider unless a formal unidentified-document export mode is added.
- Image export can remain independent and may use source filename fallback.

## Compatibility tests

Every base release should run:

- current flat JSON fixture test;
- provider migration test;
- export field order test;
- address shape test;
- mileage/mileage-unit/VAT state test;
- engineer overlay test;
- batch export test.
