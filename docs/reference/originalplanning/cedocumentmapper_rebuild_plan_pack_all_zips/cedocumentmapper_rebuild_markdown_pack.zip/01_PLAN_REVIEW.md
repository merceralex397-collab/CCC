# Plan Review and Re-Sequencing

## Assessment of the supplied plan

The supplied `phase_initial_automation.md` is useful but automation-first. It correctly identifies many of the eventual components: document mapper upgrades, Outlook intake, EVA/Sentry API calls, Box storage and spreadsheet/control-table replacement. The risk is that it asks a still-evolving desktop mapper to become the foundation for mailbox automation and EVA submission before the mapper itself has a durable architecture. fileciteturn0file0

The current repo confirms this risk. `app.py` contains extraction, mapping, provider storage, normalisation, UI, batch workflows, engineer-report overlay, export logic, image extraction, OCR setup and packaging assumptions in one file. It works as a prototype, but it is too coupled to safely extend into unattended automation. fileciteturn10file0 fileciteturn13file0 fileciteturn17file0

## Recommended re-sequencing

### Phase 1 — Rebuild the base mapper

Scope: local human-in-the-loop mapper only.

Included:

- local file import for PDF, DOC, DOCX, EML, MSG and common image/document evidence;
- provider detection and provider editor;
- typed mapping rules;
- field-level provenance, confidence labels and review status;
- batch workflows and engineer-report overlay;
- flat JSON export compatible with the current field order and `Final Format Example 02.json`; fileciteturn0file1
- image export;
- test harness and provider-rule validation.

Excluded:

- Outlook/Graph ingestion;
- Box upload/sync;
- EVA/Sentry API calls;
- automatic emails/WhatsApp;
- spreadsheet replacement beyond optional export/reporting fixtures.

### Phase 2 — Automation enhancement

Scope: feed documents into the mapper and manage case queues.

Included:

- Outlook/Graph or watched-folder intake;
- work-item queue;
- attachment and image correlation;
- Box storage;
- control dashboard/status table;
- missing-information tasks and copy-only chaser drafts.

Excluded:

- automatic EVA submission;
- autonomous external communication without human approval;
- final report generation or engineering decisions.

### Phase 3 — EVA API enhancement

Scope: submit approved, reviewed data to EVA/Sentry.

Included:

- EVA adapter from canonical case data;
- token handling;
- endpoint-specific payload builders;
- supervised submission first;
- response logging, retries and duplicate protection;
- later optional auto-submit only for proven low-risk cases.

Excluded:

- direct parser-to-EVA coupling;
- EVA credentials in the desktop mapper;
- unattended submission before evidence/review controls are mature.

## What to preserve from the current tool

Preserve the business behaviours, not the current structure.

- The canonical field order: Work Provider, VRM, Vehicle Model, Claimant Name, Reference, Incident Date, Instruction Date, Inspection Date, Inspection Address, Accident Circumstances, VAT Status, Mileage, Mileage Unit. fileciteturn10file0
- Mapping concepts: Single Label, Two Labels, Fixed Position, Fixed Position + Label, Single Label +/-, Email Date, Manual Input. fileciteturn10file0
- Provider presets and `providers.json` migration. fileciteturn11file0 fileciteturn20file0
- PDF block extraction and OCR fallback. fileciteturn13file0
- DOC/DOCX header/footer/textbox handling. fileciteturn12file0
- MSG/EML body extraction. fileciteturn12file0
- Engineer report overlay and touched-field highlighting. fileciteturn17file0 fileciteturn18file0
- Image export independent from JSON export. fileciteturn9file0

## What to change

- Convert the informal version-history requirements into formal acceptance tests.
- Split parser, rules, UI, export and persistence into separate modules.
- Replace “highlighted preview only” with field-level evidence objects.
- Version provider schemas and export profiles.
- Make the current flat JSON a compatibility profile, not the only data model.
- Add a fixture corpus and provider-rule regression suite before expanding provider coverage.
- Plan automation and EVA through stable interfaces rather than hard-coding them into the desktop app.

## Review conclusion

The right plan is not “upgrade the current app until it automates the whole workflow.” The right plan is “rebuild the mapper core so it becomes a reliable local data-extraction and review product, then attach automation and EVA adapters to that core.”
