# EVA API Enhancement Pack

This zip contains the separate EVA/Sentry API plan. It assumes reviewed canonical case data already exists and avoids direct parser-to-EVA coupling.

Read in order:

1. `09_PHASE_3_EVA_API_ENHANCEMENT_PLAN.md`
2. `10_DELIVERY_ROADMAP_AND_BACKLOG.md`
3. `11_RISKS_DECISIONS_OPEN_QUESTIONS.md`
4. `02_SOURCE_REGISTER.md`
