# Current Tool Audit

## Current position

`cedocumentmapper` is an evolved Windows desktop document-mapping tool. It currently uses a Python/Tkinter app with drag-and-drop, minimal/expanded views, provider presets, a preview panel, detected fields, export buttons and provider setup. The previous development transcript confirms these constraints and the repository now reflects many later revisions. fileciteturn0file2

## Functional strengths

1. **Practical document coverage.** The tool reads PDF, DOCX, DOC, EML and MSG. DOCX extraction includes header/footer and textbox content; DOC extraction attempts Word automation, LibreOffice conversion and antiword; MSG extraction uses `extract_msg` rather than Outlook COM automation. fileciteturn12file0
2. **Improved PDF handling.** PyMuPDF block mode is used to avoid multi-column table contamination, with pypdf fallback and OCR for scanned 1–2 page PDFs with a single image per page. fileciteturn13file0
3. **Useful mapping methods.** Current mapping methods include label-based, two-label, fixed-position, fixed-position+label, single-label offset, email-date and manual-input rules. fileciteturn10file0 fileciteturn14file0
4. **Domain-specific normalisation.** VRM, inspection address, date and mileage normalisation are implemented. Mileage Unit and VAT Status use controlled presence-check states. fileciteturn15file0
5. **Provider presets.** `providers.json` already stores real-world mappings, work-provider codes, detect phrases, current-date flags, postcode forcing and engineer-report flags. fileciteturn20file0 fileciteturn21file0
6. **Engineer-report workflow.** Engineer reports can overlay extracted non-blank fields on an instruction and visibly mark touched fields. fileciteturn17file0 fileciteturn18file0
7. **Pragmatic Windows fixes.** The app resolves actual Desktop/Documents locations through Windows Known Folders and migrates old settings, which is important for OneDrive users. fileciteturn11file0

## Structural weaknesses

1. **Monolithic code.** `app.py` mixes extraction, UI, rule parsing, provider persistence, export, normalisation, image extraction and workflow state. This is the central reason not to attach automation and EVA directly to the current implementation.
2. **Version-history requirements.** Many important behaviours live in README change notes and transcript history rather than formal requirements or tests. fileciteturn8file0 fileciteturn9file0
3. **No formal evidence model.** Field values can be highlighted in the source preview, but the export does not carry a field-level source, extraction method, confidence label, validation status or human review status.
4. **Provider presets are not governed.** The real provider list is valuable, but it needs schema validation, versioning, regression fixtures and separation between bundled defaults and user/company overrides. fileciteturn20file0
5. **No durable case model.** The current flat export is useful but insufficient for future automation, where documents, images, email metadata, review decisions, audit events and integration state matter.
6. **Exports are Desktop-oriented.** Desktop export is acceptable for the local tool; it is not a future storage/integration boundary.
7. **Testing not visible as a first-class repo asset.** The README references regression tests, but test files were not visible in the fetched repository path. The rebuild should make tests a primary deliverable.

## Current data contract

The current flat JSON contract remains important because it is what the business already expects. `Final Format Example 02.json` shows the exact labels and field order. Keep that as `legacy_flat_v1` while adding a richer internal model. fileciteturn0file1

## Current workflow dependencies

The operational handover confirms that the mapper is connected to the wider manual workflow: job-sheet tracking, provider settings, batch processing, engineer reports, OCR, and import/export operations. It also confirms fragility in the Excel/VBA job sheet and network-drive setup. fileciteturn0file9

## Rebuild implication

The current tool should be treated as a requirements capture and proving-ground artifact. The rebuilt tool should be functionally compatible where it matters but internally designed as a clean product:

- parser layer;
- rule engine;
- provider library;
- review/evidence model;
- export profiles;
- UI shell;
- future adapter interfaces.
