# Base Architecture Specification

## Design principle

The rebuilt mapper should be a local product with clean internal boundaries. The core should not know whether a file came from drag/drop, Outlook, Box or a future queue. It should accept source documents and return reviewed case data.

## Recommended package shape

```text
cedocumentmapper/
  app/
    desktop_shell.py
    views/
      detected_fields.py
      source_preview.py
      provider_editor.py
      batch_bar.py
  core/
    field_schema.py
    models.py
    statuses.py
    validation.py
    audit.py
  extraction/
    base.py
    pdf.py
    docx.py
    doc.py
    email.py
    image_media.py
    ocr.py
  mapping/
    rules.py
    rule_parser.py
    provider_model.py
    provider_store.py
    provider_migration.py
    rule_tester.py
  normalization/
    dates.py
    vrm.py
    mileage.py
    address.py
    yes_no.py
  workflow/
    document_session.py
    batch.py
    engineer_report.py
    review.py
  export/
    flat_json.py
    canonical_json.py
    image_export.py
    rjs_doc_export.py
  persistence/
    app_paths.py
    settings_store.py
    local_case_store.py
  adapters/
    automation_port.py
    eva_port.py
    storage_port.py
  tests/
    fixtures/
    unit/
    integration/
```

## Core interfaces

### Source document

```python
@dataclass
class SourceDocument:
    document_id: str
    original_path: str
    original_filename: str
    source_type: Literal["pdf", "docx", "doc", "eml", "msg", "image", "unknown"]
    checksum_sha256: str
    received_context: dict | None = None
```

### Extraction result

```python
@dataclass
class ExtractionResult:
    document_id: str
    text: str
    blocks: list[TextBlock]
    images: list[ExtractedImage]
    warnings: list[ExtractionWarning]
    extractor_name: str
```

### Field result

```python
@dataclass
class FieldResult:
    key: str
    label: str
    value: str
    normalized_value: str | None
    status: Literal["Strong", "Check", "Blocked", "Missing"]
    method: str
    evidence: list[EvidenceSpan]
    warnings: list[str]
    touched_by_engineer_report: bool = False
    manually_edited: bool = False
```

### Provider rule set

```python
@dataclass
class ProviderRuleSet:
    provider_id: str
    display_name: str
    work_provider_code: str
    detect_phrases: list[str]
    rules: dict[str, RuleConfig]
    flags: ProviderFlags
    schema_version: str
```

### Case draft

```python
@dataclass
class CaseDraft:
    case_id: str
    documents: list[SourceDocument]
    provider: ProviderMatch
    fields: dict[str, FieldResult]
    review_status: str
    audit: list[AuditEvent]
```

## Dependency direction

```text
UI -> workflow -> mapping/extraction/normalization/core -> persistence/export

adapters -> core interfaces only
```

The `automation_port`, `eva_port` and `storage_port` modules should define interfaces only during the base phase. Implementations arrive later.

## Why use ports now

The base app should be enhanceable without rewiring core logic. Ports let the rebuild support later integrations without building them now:

```python
class IntakeAdapter(Protocol):
    def list_new_documents(self) -> list[SourceDocument]: ...

class StorageAdapter(Protocol):
    def archive_source(self, document: SourceDocument) -> ArchivedDocument: ...

class EvaAdapter(Protocol):
    def validate_payload(self, case: CaseDraft) -> EvaValidationResult: ...
    def submit(self, approved_case: CaseDraft) -> EvaSubmissionResult: ...
```

During Phase 1 these interfaces remain unimplemented or stubbed.

## UI technology recommendation

Two viable routes:

1. **Python desktop rebuild.** Continue Python to reuse extraction libraries, but use a cleaner architecture. Tkinter can remain for speed; PySide6/PyQt would give a stronger modern UI if packaging effort is acceptable.
2. **Hybrid app + parser service.** Use a UI shell with a local parser service. CollisionPDF’s architecture proposes a native shell, local parser API, worker, database and immutable archive. fileciteturn30file0 This is better for full automation, but may be heavier than needed for the first mapper-only rebuild.

Recommended: build Phase 1 as a modular Python desktop app with a clean core. Keep the parser core service-friendly so it can be moved behind a local API later.

## Local persistence

Use separate stores:

- `settings.json`: UI settings only.
- `provider_rules.json`: provider presets, schema versioned.
- `provider_rules_backup/`: auto backups before migrations.
- `case_history.sqlite` or `case_history.jsonl`: optional local reviewed-case/audit history.
- `fixtures/`: sample documents and expected outputs for tests, not user data.

The current app already resolves OneDrive-safe Documents/Desktop paths and migrates legacy settings; preserve that behaviour in `app_paths.py`. fileciteturn11file0

## Packaging

Keep the PyInstaller-style portable Windows distribution if that remains operationally useful. Requirements should be pinned with reproducible lock files. Current dependency families are known from `requirements.txt`. fileciteturn19file0

Do not bundle large binaries such as Tesseract directly in source; `.gitignore` already treats `tesseract/` as a large OS-specific artifact. fileciteturn22file0
