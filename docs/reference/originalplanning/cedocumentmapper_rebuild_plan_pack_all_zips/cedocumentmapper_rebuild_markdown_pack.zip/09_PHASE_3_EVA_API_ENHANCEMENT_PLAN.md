# Phase 3: EVA / Sentry API Enhancement Plan

## Position in roadmap

EVA integration starts after the base mapper and automation/review layers can produce approved canonical case data. EVA should be an adapter fed by approved data, not a parser concern.

## Relevant EVA/Sentry sources

The Sentry guide describes JWT authentication, a 5-minute token expiry, and endpoints for submitting instructions, locations, authority status, notes, claim updates, reports and report retrieval. fileciteturn0file5 The PDF API documentation gives detailed request/response models for Instruct Claim, Claim Location Update, Authority Status Update, Submit Note and other operations. fileciteturn0file6

The EVA setup guide also documents the manual workflow: offline email, instruction, images, Reg No, Principal, Inspection Type, Case ID/PO, insured name, Claim No, Incident Date, current inspected date, inspection address or image-based assessment, Speedo/mileage, valuation and photo-order rules. fileciteturn0file4

## Goal

Submit reviewed case data to EVA/Sentry safely, with validation, payload previews, duplicate protection and audit logging.

## Integration boundary

```text
Reviewed CaseDraft
  -> EvaPayloadBuilder
  -> EvaValidator
  -> Human approval / supervised submit
  -> SentryClient
  -> ResponseLog / Audit
```

## Phase 3 subphases

### E1 — Payload preview only

- Map canonical case fields to EVA/Sentry candidate payloads.
- Do not submit.
- Show payload preview, missing fields and validation warnings.
- Compare with manual EVA setup steps.

### E2 — Sandbox/supervised submit

- Implement token client.
- Submit to EVA sandbox/test route if available.
- Store request/response logs.
- Human operator clicks submit.
- Failed submissions remain reviewable and retryable.

### E3 — Production supervised submit

- Use production credentials with strict permissions.
- Require approved case status.
- Require payload validation.
- Add duplicate checks.
- Record response ID/status.

### E4 — Additional endpoint coverage

Add only as needed:

- `POST /Instruction/Inspection` for initial instruction.
- `POST /Claim/LocationUpdate` for location/address updates.
- `POST /Claim/AuthorityStatusUpdate` for authority updates.
- `POST /Note/SubmitNote` for notes/missing information interactions.
- `POST /Claim/Update` for claim updates.
- `POST /Report/SubmitReport` for report submission, if the workflow extends beyond intake.
- retrieval endpoints for reports/status where operationally useful.

### E5 — Limited auto-submit

Only after enough measured pilot data supports it:

- narrow provider/document class;
- all mandatory fields Strong/manual-confirmed;
- no conflicts;
- recent successful submission history;
- reversible failure handling;
- operator can disable instantly.

## Payload mapping considerations

### Current mapper fields

| Mapper field | EVA relevance |
|---|---|
| Work Provider | maps to internal/principal/work-provider code; may also inform `RequestFrom`/principal mapping. |
| VRM | maps to `VehReg`. |
| Vehicle Model | maps to vehicle description fields, depending on EVA endpoint. |
| Claimant Name | maps to claimant/insured/client fields. |
| Reference | maps to claim/client/external reference depending on provider. |
| Incident Date | maps to `DtIncident`. |
| Instruction Date | maps to request/received date or note. |
| Inspection Date | maps to inspection date where endpoint supports it. |
| Inspection Address | maps to inspection/claim/repairer location fields. |
| Accident Circumstances | maps to cause/notes. |
| VAT Status | maps to `VatStat` or claim update fields. |
| Mileage | maps to speedo/mileage where supported. |
| Mileage Unit | likely internal/export metadata unless EVA requires unit. |

### Manual EVA-only fields to model before integration

From the EVA user guide:

- internal Case ID/PO;
- principal/EVA code;
- inspection type;
- image-based assessment vs named address;
- request date from email received date;
- speedo source: dashboard image vs estimated;
- valuation source and values;
- special first two images for photo upload order. fileciteturn0file4

These are not fully represented in the current flat mapper JSON, so the canonical model must be extended before serious EVA integration.

## Security controls

- Store credentials outside source and outside provider presets.
- Token cache in memory only.
- Automatic refresh before expiry.
- Request/response logs redact secrets and personal data where appropriate.
- Role-based ability to submit.
- All submissions auditable by operator, timestamp, payload version and response.

## Phase 3 exit criteria

- EVA payload preview maps approved cases correctly.
- Token handling and retry behaviour are tested.
- Duplicate checks exist.
- Human approval gate works.
- Sentry responses are logged.
- Failure states are visible in the dashboard.
- No parser or provider rule directly calls EVA.
