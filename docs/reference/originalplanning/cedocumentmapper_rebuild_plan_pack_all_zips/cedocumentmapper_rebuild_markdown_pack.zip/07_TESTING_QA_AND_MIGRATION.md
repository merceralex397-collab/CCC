# Testing, QA and Migration Plan

## Testing principle

The rebuilt mapper must convert the existing informal testing culture into a fixture-driven release gate. Every previously fixed bug should become a regression fixture.

## Test levels

### Unit tests

- normalisers: VRM, date, inspection address, mileage, VAT, mileage unit;
- rule parsing: comma tokens, `start || end`, fixed line formats, offsets;
- mapping methods: each method with positive and negative cases;
- provider detection: all phrases required; longest/more specific provider wins;
- export profile order and labels.

### Extractor tests

- PDF block extraction preserves table cells;
- pypdf fallback decodes `/uniXXXX` sequences;
- OCR fires only under defined conditions;
- DOCX extracts headers, footers, tables and textboxes;
- DOC extraction works through Word/LibreOffice pathways where available;
- MSG HTML and bytes bodies are cleaned to plain text;
- EML plain/HTML multipart behaviour;
- image extraction from PDF/DOCX/DOC.

### Workflow tests

- single-file load;
- batch mode;
- single instruction + engineer report;
- engineer report after instruction;
- invalid multiple instruction + engineer report;
- invalid multiple engineer reports;
- engineer report without instruction;
- touched-field highlighting state;
- clearing state on fresh drag/drop.

### Provider tests

Each provider should have:

- at least one instruction fixture;
- expected detected provider;
- expected work provider code;
- expected field values;
- expected field statuses;
- expected warnings.

Provider fixtures must be anonymised before storing in source.

### UI tests

- minimal view opens at the intended size;
- expanded view opens with all panels;
- provider editor save/load round trip;
- presence-check fields do not show method dropdowns;
- rule tester previews source evidence;
- export buttons behave correctly.

## Migration plan

### Source provider migration

1. Read old `providers.json`.
2. Validate it against an `old_provider_rules` permissive schema.
3. Convert to `provider_rules.v1`.
4. Preserve original as timestamped backup.
5. Write migrated file only after schema validation.
6. Log conversion changes.

### User settings migration

- Preserve old window/view settings.
- Continue OneDrive-safe Documents/Desktop path handling.
- Copy old files from legacy Documents path if not already migrated. Current code already contains a migration pattern for this. fileciteturn11file0

### Export compatibility migration

- Keep `legacy_flat_v1` output exactly compatible during the pilot.
- Add canonical export only as a separate optional export until operations approves it.

## Fixture corpus plan

Create a private, anonymised corpus:

```text
fixtures/
  pdf_engineer_report_table/
  pdf_scanned_letter/
  docx_header_footer_textbox/
  doc_legacy_header_footer/
  eml_plain/
  eml_html/
  msg_html_body/
  provider_sbl/
  provider_rjs/
  provider_cnx_engineers/
  provider_eva_engineers/
```

Each fixture folder should contain:

- original/anonymised file;
- extracted text snapshot;
- expected field JSON;
- evidence expectations;
- notes/warnings expectations.

## Release gate

A build can be released only when:

- all unit and extractor tests pass;
- provider fixtures pass;
- export compatibility test passes;
- migration dry-run passes;
- packaging smoke test passes on Windows;
- no test uses live client data in source.

## Pilot validation

Run shadow mode for live operations:

1. Staff continues using existing process.
2. New mapper processes the same documents.
3. Compare extracted values against staff output.
4. Record differences by field/provider/extractor.
5. Fix provider rules and extractor behaviour.
6. Only then replace the current app.

## Documentation required per release

- version summary;
- changed behaviours;
- provider migration notes;
- fixture/test coverage delta;
- known issues;
- rollback path.
